-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2024 at 08:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(120) DEFAULT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `FullName`, `AdminEmail`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'Shubham Gupta', 'shubhamgupta072004@gmail.com', 'admin', 'e6e061838856bf47e1de730719fb2609', '2024-09-03 09:32:07');

-- --------------------------------------------------------

--
-- Table structure for table `tblauthors`
--

CREATE TABLE `tblauthors` (
  `id` int(11) NOT NULL,
  `AuthorName` varchar(159) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblauthors`
--

INSERT INTO `tblauthors` (`id`, `AuthorName`, `creationDate`, `UpdationDate`) VALUES
(1, 'Hugh Williams', '2024-08-30 10:43:18', NULL),
(2, 'Seyed M.M. (Saied) Tahaghoghi', '2024-08-30 10:43:59', NULL),
(3, 'L. Ashok Kumar', '2024-08-30 10:50:46', NULL),
(4, 'William S. Vincent', '2024-08-30 10:57:08', NULL),
(5, 'Bjarne', '2024-08-30 11:12:59', NULL),
(6, 'William B. Brueggeman', '2024-08-30 11:25:28', NULL),
(7, 'James Clear', '2024-08-30 11:33:43', NULL),
(8, 'Robert T. Kiyosaki', '2024-08-30 11:37:39', NULL),
(9, 'Ajay Agrawal, Joshua Gans, Avi Goldfarb', '2024-08-30 11:49:12', NULL),
(10, 'David Poole', '2024-08-30 11:53:09', NULL),
(11, 'Alan Beaulieu', '2024-08-30 11:57:50', NULL),
(12, 'Sufyan bin Uzayr', '2024-08-30 12:00:59', NULL),
(13, 'Roger Kinsky', '2024-08-30 12:05:25', NULL),
(14, 'Gabriele Meiselwitz', '2024-08-30 12:10:25', NULL),
(15, 'Joel L. Fleishman', '2024-08-30 12:14:15', NULL),
(16, 'Allen Carr', '2024-08-30 12:21:09', NULL),
(17, 'Jeremiah Desmarais', '2024-08-30 15:15:37', NULL),
(18, 'Leslie G. Eldenburg', '2024-08-30 15:27:16', NULL),
(19, 'Hilary Falb Kalisman', '2024-08-30 15:33:53', NULL),
(20, 'Horstmann Cay', '2024-08-30 15:41:42', NULL),
(21, 'Sufyan bin Uzayr', '2024-08-30 15:51:39', NULL),
(22, 'Tony Davidow', '2024-08-30 15:57:18', NULL),
(23, 'Elena Armas', '2024-08-31 08:06:03', NULL),
(24, 'Douglas W.Hubbard; RICHARD SEIERSEN', '2024-08-31 08:57:03', NULL),
(25, ' Laura Nowlin', '2024-08-31 10:00:43', NULL),
(26, 'Clare Martin', '2024-08-31 10:08:39', NULL),
(27, 'Chuck D. Pierce; Rebecca Wagner Sytsema', '2024-08-31 10:12:34', NULL),
(28, 'Emily Henry', '2024-08-31 10:18:22', NULL),
(29, 'Clark, Nathan', '2024-08-31 10:25:13', NULL),
(30, 'Peter Taylor', '2024-08-31 10:30:39', NULL),
(31, ' Robert Cecil Martin', '2024-08-31 10:38:23', NULL),
(32, 'George Soros', '2024-08-31 10:54:41', NULL),
(33, 'Daniel Kahneman', '2024-08-31 10:57:40', NULL),
(34, 'Jon Duckett', '2024-08-31 11:01:25', NULL),
(35, 'Sheldon Axler', '2024-08-31 11:05:39', NULL),
(36, ' Dr Panda Srutirupa ', '2024-08-31 11:08:18', NULL),
(37, 'Patrick Rothfuss ', '2024-08-31 11:12:24', NULL),
(38, 'Amish Tripathi', '2024-08-31 11:15:19', NULL),
(39, 'Michael Walker ', '2024-08-31 11:19:09', NULL),
(40, 'Zvi Bodie;Alex Kane;Alan J. Marcus;Pitabas Mohanty', '2024-08-31 11:25:00', NULL),
(41, 'M. Laxmikanth', '2024-08-31 16:20:21', NULL),
(42, 'Nitin Singhania', '2024-08-31 16:22:30', NULL),
(43, 'Ramesh Singh', '2024-08-31 16:30:59', NULL),
(44, 'Warren R. Sullivan', '2024-08-31 16:41:01', NULL),
(45, 'Shane Lee', '2024-08-31 16:54:42', NULL),
(46, 'Brenda S. Gardenour Walter', '2024-08-31 17:05:55', NULL),
(47, 'Frederick J. Day', '2024-08-31 17:12:27', NULL),
(48, 'Benjamin Netanyahu', '2024-08-31 17:19:38', NULL),
(49, 'Kenneth D. Keith', '2024-08-31 17:51:54', NULL),
(50, 'Abdelilah Hamdouchi', '2024-08-31 17:56:41', NULL),
(51, 'Hill, Napoleon', '2024-08-31 18:02:20', NULL),
(52, 'Robert Keller', '2024-08-31 18:10:53', NULL),
(53, 'Rolf Giesen', '2024-08-31 18:16:12', NULL),
(54, 'Chris Robinson, Tom McSorley', '2024-08-31 18:22:47', NULL),
(55, 'Geetanjali Shree', '2024-08-31 18:27:27', NULL),
(56, 'Stig H. Moberg', '2024-08-31 18:31:20', NULL),
(57, 'Herron, Mick', '2024-08-31 18:34:48', NULL),
(58, 'Glenn Stout', '2024-08-31 18:45:27', NULL),
(59, 'Cixin Liu', '2024-08-31 18:51:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblbooks`
--

CREATE TABLE `tblbooks` (
  `id` int(11) NOT NULL,
  `BookName` varchar(255) DEFAULT NULL,
  `CatId` int(11) DEFAULT NULL,
  `AuthorId` int(11) DEFAULT NULL,
  `ISBNNumber` varchar(25) DEFAULT NULL,
  `BookPrice` decimal(10,2) DEFAULT NULL,
  `bookImage` varchar(250) NOT NULL,
  `isIssued` int(1) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblbooks`
--

INSERT INTO `tblbooks` (`id`, `BookName`, `CatId`, `AuthorId`, `ISBNNumber`, `BookPrice`, `bookImage`, `isIssued`, `RegDate`, `UpdationDate`) VALUES
(1, 'Learning MySQL', 1, 1, '0596008643', 4536.00, 'e0e0306db79ea15c283b78b47d448a1c.jpg', 0, '2024-08-30 10:48:18', '2024-09-03 10:07:57'),
(2, 'Machine Learning for Decision Sciences with Case Studies in Python', 2, 3, '1032193565', 4599.00, '466028dfd28ff0a751a820587521a45c.jpg', NULL, '2024-08-30 10:54:38', NULL),
(3, 'Django for Professionals: Production websites with Python & Django 4.0', 4, 4, '1735467235', 5499.00, '189992685f8811300c8e2632faa035fd.jpg', NULL, '2024-08-30 11:08:36', NULL),
(4, 'A Tour of C++, Second Edition', 5, 5, '0134998057', 5974.00, 'ff58b747710d5eb32787d33d3c3dc14c.jpg', NULL, '2024-08-30 11:18:40', NULL),
(5, 'Real Estate Finance & Investments', 6, 6, '1264892888', 4869.00, '9afcec5fdbdc7ed9c3832c970868c785.jpg', NULL, '2024-08-30 11:29:22', NULL),
(6, 'Atomic Habits', 7, 7, '1847941834', 999.00, 'a79b23e364a66a011ccc6f6fa0cb3ef8.jpg', NULL, '2024-08-30 11:36:10', NULL),
(7, 'Rich Dad Poor Dad', 8, 8, '978-1-61268-018-7', 1299.00, '28d60c09c8b8481107c42aa92b4df92c.jpg', NULL, '2024-08-30 11:40:12', NULL),
(8, 'Prediction Machines, Updated and Expanded', 2, 9, '9781647824679', 889.00, 'aae203f9caee79606733eb6a1e48eca8.jpg', NULL, '2024-08-30 11:51:34', NULL),
(9, 'Linear Algebra', 10, 10, '1285463242', 950.00, 'fda97503ff22239fd42fdde2b3e9172d.jpg', NULL, '2024-08-30 11:55:44', NULL),
(12, 'Starting with Shares', 8, 13, '9780730395188', 1411.00, '31adb5443e0b11277c577c41b0d6bbba.jpg', NULL, '2024-08-30 12:07:47', NULL),
(13, 'Social Computing and Social Media', 11, 14, '3031050630', 6295.00, '3f3de8f1633fef88a79897bf7164c402.jpg', NULL, '2024-08-30 12:12:38', NULL),
(14, 'Putting Wealth to Work', 12, 15, '9781610395328', 1244.00, '0f041391872eefa7b07a5c4f12430889.jpg', NULL, '2024-08-30 12:18:26', NULL),
(15, ' Stop Drinking Now', 7, 16, '9781784280567', 981.00, '1871ff4655f69e2aab680a576931746b.jpg', NULL, '2024-08-30 12:25:12', NULL),
(16, 'Shift', 8, 17, '2017902542', 1560.00, '4ed52cc550d4b506e596786267ad7a9fjpeg', NULL, '2024-08-30 15:18:46', '2024-08-30 15:19:54'),
(17, 'Cost Management', 8, 18, '9781119254331', 21945.00, '9f43ecd7e14f035b0300eb5abb33a00b.jpg', NULL, '2024-08-30 15:29:41', NULL),
(18, 'Teachers as State-Builders', 11, 19, '0691204330', 1752.00, '9b0f0dbf233097332365654e2feb5cf4.jpg', NULL, '2024-08-30 15:36:13', NULL),
(19, 'Core Java', 2, 20, '9780137673629', 4900.00, '7ebef82f159a745e91538ec9ea980db7.jpg', NULL, '2024-08-30 15:47:15', NULL),
(20, 'Mastering React', 2, 21, '1032313587', 2459.00, '828fe36a4b796636eec93e12cc77616a.jpg', NULL, '2024-08-30 15:54:49', NULL),
(21, 'Goals-Based Investing', 13, 22, '1264268211', 1500.00, 'ef6553d6d9cbf5a0870024321fb8262f.jpg', NULL, '2024-08-30 15:59:57', NULL),
(22, 'The SPANISH Love Deception ', 14, 23, '8705893844v', 399.00, '977eb836b8d753aa3d7fe502f11738ba.jpg', 0, '2024-08-31 08:10:32', '2024-09-03 10:08:29'),
(23, 'How to Measure Anything in Cybersecurity Risk', 2, 24, '9781119892304', 3679.00, '61cc807d972ee6bd0939cf2e3080f358.jpg', NULL, '2024-08-31 08:58:00', NULL),
(24, 'If He Had Been with Me', 14, 25, '1402277830', 239.00, 'a9a2dccec26e64af82f4bf269dd8317c.jpg', NULL, '2024-08-31 10:03:20', NULL),
(25, ' Mapping the Psyche 3', 16, 26, '1910531138', 1913.00, 'b820404f311d4b0bb6ad105c49614c14.jpg', NULL, '2024-08-31 10:11:17', NULL),
(26, 'When God Speaks', 17, 27, '9781441268570', 1290.00, '72d1b420a873b94600a4c595ea02ce0d.jpg', NULL, '2024-08-31 10:15:24', NULL),
(27, 'Happy Place', 14, 28, '0241997933', 441.00, '78109d82cdda070a06d2881c916d584e.jpg', NULL, '2024-08-31 10:22:07', NULL),
(28, 'JAVA', 5, 29, 'B076926QSX', 250.00, 'e348f37c7011cbe81f4e1c6f3388c923.jpg', NULL, '2024-08-31 10:28:40', NULL),
(29, 'The Art Of Laziness', 7, 30, '0143469126', 180.00, '4fa548870a7856a8829f7aad63ffd538.jpg', NULL, '2024-08-31 10:33:50', NULL),
(30, 'Clean Code', 18, 31, '0132350882', 2.00, '3eb156b57b2eeb6fe58a52fada6a7a91.jpg', NULL, '2024-08-31 10:43:16', NULL),
(31, 'The Alchemy of Finance', 6, 32, '0471445495', 1869.00, '39df1cc7fe3aec8721cd81687e4388da.jpg', NULL, '2024-08-31 10:56:16', NULL),
(32, 'Thinking, Fast and Slow', 16, 33, '9780141033570', 500.00, '19b70d0fd3a2fbe6db642733ae270ca5.jpg', NULL, '2024-08-31 10:59:18', NULL),
(33, ' HTML and CSS', 5, 34, '1118008189', 2.00, 'a9b917b10fe69a8e12a6a4dc1827ba70.jpg', NULL, '2024-08-31 11:04:11', NULL),
(34, 'Linear algebra done right', 10, 35, '3319110799', 2240.00, '004d152aff93eeee39004b0d26e6c787.jpg', NULL, '2024-08-31 11:07:14', NULL),
(35, 'EDUCATION SOCIETY AND CULTURE', 11, 36, '9798885694520', 234.00, 'b66f9e8e1ed1fe229ea27f2a219fcf1f.jpg', NULL, '2024-08-31 11:10:49', NULL),
(36, 'The Name of the Wind', 9, 37, '0575081406', 416.00, '523096ae5004441ab67a06779ad73f19.jpg', NULL, '2024-08-31 11:14:04', NULL),
(37, 'The Immortals of Meluha', 17, 38, '9356290520', 215.00, 'b415e570f36ba67ae08ffadea79cf809.jpg', NULL, '2024-08-31 11:17:15', NULL),
(38, 'Python Data Cleaning Cookbook', 4, 39, '1803239875', 3000.00, '23124cdd693899cbe8f6e14f8770fbdb.jpg', NULL, '2024-08-31 11:20:55', NULL),
(39, 'Investments', 12, 40, '8194113857', 555.00, '35d80e8d393d1ec77e7242a34e6e7839.png', NULL, '2024-08-31 11:29:05', NULL),
(40, 'Indian Polity', 19, 41, '9355325347', 709.00, '52e5ae6362216c3b09e9c3657a04de84.jpg', NULL, '2024-08-31 16:21:25', NULL),
(41, 'Indian Art and Culture', 19, 42, 'B0B6D31W3M', 875.00, 'fd3c5a46f2c19e34e772d2a453080264.jpg', NULL, '2024-08-31 16:26:26', NULL),
(42, 'Indian Economy', 19, 43, '9390727421', 627.00, 'e3101603880d01b7b09f3fbd9befd66f.jpg', NULL, '2024-08-31 16:35:26', NULL),
(43, 'Procrastination', 7, 44, '9781516365630', 1545.00, 'c5984d035b66125a9014c81062fc7d5a.jpg', NULL, '2024-08-31 16:47:39', NULL),
(44, 'Black Forest', 20, 45, '1087924642', 885.00, '24a7a081843b17ed73c861df0731165c.jpg', NULL, '2024-08-31 16:57:00', NULL),
(45, 'Our Old Monsters', 20, 46, '9781476619422', 2910.00, 'a5e1955c5c0ed3a4fcc45c208343b7bb.jpg', NULL, '2024-08-31 17:09:20', NULL),
(46, 'Dream Team', 21, 47, '2021917533', 1696.00, '78b3fe5f3216f7b20820c886f6cb0694.jpg', NULL, '2024-08-31 17:14:45', NULL),
(47, 'Bibi', 22, 48, '9781668008461', 1750.00, 'd06f5333dfc8de42b6448b2eef02d264.jpg', NULL, '2024-08-31 17:22:33', NULL),
(48, 'Cross-Cultural Psychology', 16, 49, '1119438403', 5604.00, '79fdc8fc9f88468474ae1fed56fbb765.jpg', NULL, '2024-08-31 17:54:07', NULL),
(49, 'Bled Dry', 23, 50, '9789774168482', 1430.00, '08b8cb4c32ed1f08602ea1c16383a9c9.jpg', NULL, '2024-08-31 17:59:03', NULL),
(50, 'Think and Grow Rich', 7, 51, '9783959721714', 2110.00, '3b7f9a2c3b2d70a6a35e7ed475bb3e3b.jpg', NULL, '2024-08-31 18:04:35', NULL),
(51, 'Bundy', 24, 52, '154873067X', 303.00, 'f16d728f312021b6a47e6c359920d3ae.jpg', NULL, '2024-08-31 18:13:38', NULL),
(52, 'Animation in Europe', 25, 53, '036764052X', 4892.00, 'dc8c7c78a56a4589d0ce168669ed34cd.jpg', NULL, '2024-08-31 18:21:26', NULL),
(53, 'The Corners are Glowing', 25, 54, '9781032263793', 11163.00, 'a94cb4c6879279c9b0e6e3c25e0eb36e.jpg', NULL, '2024-08-31 18:25:10', NULL),
(54, 'The Roof Beneath Their Feet', 14, 55, '9789350296318', 1458.00, '3eb33f6996cefa088c45446bcd20b7a3.jpg', NULL, '2024-08-31 18:29:33', NULL),
(55, 'Dead Lions', 23, 57, '9781616952266', 1021.00, 'fc59ac92bb0fed1ceb1c2b521c72745e.jpg', NULL, '2024-08-31 18:38:01', NULL),
(56, 'The Dark Forest', 30, 59, '0765386690', 879.00, 'f59000310239216986b93f4cef764411.jpg', NULL, '2024-08-31 18:56:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(150) DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Status`, `CreationDate`, `UpdationDate`) VALUES
(1, 'MySQL', 1, '2024-08-30 10:42:03', '0000-00-00 00:00:00'),
(2, 'Computers & Technology', 1, '2024-08-30 10:42:37', '0000-00-00 00:00:00'),
(4, 'Python', 1, '2024-08-30 11:02:03', '0000-00-00 00:00:00'),
(5, 'Programming Languages', 1, '2024-08-30 11:11:25', '0000-00-00 00:00:00'),
(6, 'Business & Finance', 1, '2024-08-30 11:23:58', '0000-00-00 00:00:00'),
(7, 'Self-help', 1, '2024-08-30 11:33:20', '0000-00-00 00:00:00'),
(9, 'Fantasy ', 1, '2024-08-30 11:43:38', '0000-00-00 00:00:00'),
(10, 'Linear Algebra', 1, '2024-08-30 11:52:51', '0000-00-00 00:00:00'),
(11, 'Education', 1, '2024-08-30 12:10:00', '0000-00-00 00:00:00'),
(12, 'Investing', 1, '2024-08-30 12:15:14', '0000-00-00 00:00:00'),
(13, 'Personal Finance ', 1, '2024-08-30 15:56:56', '0000-00-00 00:00:00'),
(14, 'Romance', 1, '2024-08-31 08:04:42', '0000-00-00 00:00:00'),
(16, 'Psychology', 1, '2024-08-31 10:08:12', '0000-00-00 00:00:00'),
(17, 'Religion and Spirituality', 1, '2024-08-31 10:13:23', '0000-00-00 00:00:00'),
(18, 'Web Development', 1, '2024-08-31 10:39:11', '0000-00-00 00:00:00'),
(19, 'UPSC', 1, '2024-08-31 16:19:59', '0000-00-00 00:00:00'),
(20, 'Horror', 1, '2024-08-31 16:52:36', '0000-00-00 00:00:00'),
(21, 'Inspiration', 1, '2024-08-31 17:12:01', '0000-00-00 00:00:00'),
(22, 'Autobiography', 1, '2024-08-31 17:19:19', '0000-00-00 00:00:00'),
(23, 'Mystery and Thrille', 1, '2024-08-31 17:56:15', '0000-00-00 00:00:00'),
(24, 'True Crime', 1, '2024-08-31 18:10:01', '0000-00-00 00:00:00'),
(25, 'Arts and Entertainment', 1, '2024-08-31 18:15:46', '0000-00-00 00:00:00'),
(26, 'Fiction', 1, '2024-08-31 18:30:56', '0000-00-00 00:00:00'),
(27, 'Autobiographies', 1, '2024-08-31 18:41:55', '0000-00-00 00:00:00'),
(28, 'Biographies', 1, '2024-08-31 18:44:53', '0000-00-00 00:00:00'),
(29, 'Biographies', 1, '2024-08-31 18:45:10', '0000-00-00 00:00:00'),
(30, 'Science Fiction', 1, '2024-08-31 18:53:10', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tblissuedbookdetails`
--

CREATE TABLE `tblissuedbookdetails` (
  `id` int(11) NOT NULL,
  `BookId` int(11) DEFAULT NULL,
  `StudentID` varchar(150) DEFAULT NULL,
  `IssuesDate` timestamp NULL DEFAULT current_timestamp(),
  `ReturnDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `RetrunStatus` int(1) DEFAULT NULL,
  `fine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblissuedbookdetails`
--

INSERT INTO `tblissuedbookdetails` (`id`, `BookId`, `StudentID`, `IssuesDate`, `ReturnDate`, `RetrunStatus`, `fine`) VALUES
(7, 1, 'SID013', '2024-09-03 10:06:50', '2024-09-03 10:07:57', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblstudents`
--

CREATE TABLE `tblstudents` (
  `id` int(11) NOT NULL,
  `StudentId` varchar(100) DEFAULT NULL,
  `FullName` varchar(120) DEFAULT NULL,
  `EmailId` varchar(120) DEFAULT NULL,
  `MobileNumber` char(11) DEFAULT NULL,
  `Password` varchar(120) DEFAULT NULL,
  `Status` int(1) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblstudents`
--

INSERT INTO `tblstudents` (`id`, `StudentId`, `FullName`, `EmailId`, `MobileNumber`, `Password`, `Status`, `RegDate`, `UpdationDate`) VALUES
(12, 'SID013', 'Mukesh Kumar Tiwari', 'mukesh@lms.com', '999009999', 'a883bde368145d717b99c70594fd6069', 1, '2024-09-03 10:05:27', NULL),
(13, 'SID014', 'Shubham Gupta', 'shubham@lms.com', '9999999999', '3b6beb51e76816e632a40d440eab0097', 1, '2024-09-08 16:07:49', '2024-09-08 16:15:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblauthors`
--
ALTER TABLE `tblauthors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooks`
--
ALTER TABLE `tblbooks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblissuedbookdetails`
--
ALTER TABLE `tblissuedbookdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblstudents`
--
ALTER TABLE `tblstudents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `StudentId` (`StudentId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblauthors`
--
ALTER TABLE `tblauthors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `tblbooks`
--
ALTER TABLE `tblbooks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tblissuedbookdetails`
--
ALTER TABLE `tblissuedbookdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblstudents`
--
ALTER TABLE `tblstudents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
