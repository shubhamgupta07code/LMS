<?php 
session_start();
include('includes/config.php');
error_reporting(0);
if(isset($_POST['signup']))
{
 
//Code for student ID
$count_my_page = ("studentid.txt");
$hits = file($count_my_page);
$hits[0] ++;
$fp = fopen($count_my_page , "w");
fputs($fp , "$hits[0]");
fclose($fp); 
$StudentId= $hits[0];   
$fname=$_POST['fullanme'];
$mobileno=$_POST['mobileno'];
$email=$_POST['email']; 
$password=md5($_POST['password']); 
$status=1;
$sql="INSERT INTO  tblstudents(StudentId,FullName,MobileNumber,EmailId,Password,Status) VALUES(:StudentId,:fname,:mobileno,:email,:password,:status)";
$query = $dbh->prepare($sql);
$query->bindParam(':StudentId',$StudentId,PDO::PARAM_STR);
$query->bindParam(':fname',$fname,PDO::PARAM_STR);
$query->bindParam(':mobileno',$mobileno,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':password',$password,PDO::PARAM_STR);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
echo '<script>alert("Your Registration successfull and your student id is  "+"'.$StudentId.'")</script>';
}
else 
{
echo "<script>alert('Something went wrong. Please try again');</script>";
}
}

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
    <title>S&M Library Management System | Student Signup</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

    <!-- CUSTOM 3D STYLE -->
    <style>
        /* Body background and container styling */
        body {
            background: linear-gradient(to right, #8e44ad, #3498db);
            font-family: 'Open Sans', sans-serif;
        }
        .content-wrapper {
            margin-top: 50px;
        }

        /* Header styling */
        .header-line {
            color: white;
            font-weight: bold;
            text-align: center;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.3);
        }

        /* Centering container */
        .panel-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 80vh; /* Full viewport height */
        }

        /* Panel and form styling */
        .panel {
            width: 100%;
            max-width: 600px; /* Adjust to your preferred max width */
            background: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
            margin: 0 auto; /* Center the panel horizontally */
        }
        .panel-heading {
            background: linear-gradient(45deg, #e74c3c, #c0392b);
            color: white;
            font-size: 18px;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
            text-align: center;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
            padding: 15px;
        }
        .panel-body {
            padding: 30px;
        }

        /* Input fields styling */
        .form-control {
            border-radius: 5px;
            box-shadow: inset 0 2px 5px rgba(0,0,0,0.1);
            transition: transform 0.2s ease-in-out;
        }
        .form-control:focus {
            transform: scale(1.02);
            box-shadow: 0 5px 10px rgba(0,0,0,0.2);
        }

        /* Button styling */
        .btn-danger {
            background: linear-gradient(45deg, #e74c3c, #c0392b);
            border: none;
            border-radius: 50px;
            color: white;
            font-weight: bold;
            padding: 10px 20px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
            box-shadow: 0 5px 10px rgba(0,0,0,0.3);
            transition: background 0.3s, transform 0.2s ease-in-out;
        }
        .btn-danger:hover {
            background: linear-gradient(45deg, #c0392b, #e74c3c);
            transform: scale(1.05);
        }

        /* Adjustments for mobile view */
        @media (max-width: 768px) {
            .panel {
                margin-top: 20px;
            }
            .btn-danger {
                width: 100%;
            }
        }
    </style>

    <script type="text/javascript">
        function valid() {
            if (document.signup.password.value != document.signup.confirmpassword.value) {
                alert("Password and Confirm Password Field do not match  !!");
                document.signup.confirmpassword.focus();
                return false;
            }
            return true;
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function checkAvailability() {
            $("#loaderIcon").show();
            jQuery.ajax({
                url: "check_availability.php",
                data: 'emailid=' + $("#emailid").val(),
                type: "POST",
                success: function (data) {
                    $("#user-availability-status").html(data);
                    $("#loaderIcon").hide();
                },
                error: function () { }
            });
        }
    </script>
</head>
<body>
    <!------MENU SECTION START-->
    <?php include('includes/header.php'); ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User Signup</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- Centering container -->
                    <div class="panel-container">
                        <div class="panel panel-danger">
                            <div class="panel-heading" style="color: white;">
                                NEW USER SIGNUP 
                            </div>
                            <div class="panel-body">
                                <form name="signup" method="post" onSubmit="return valid();">
                                    <div class="form-group">
                                        <label>Enter Full Name</label>
                                        <input class="form-control" type="text" name="fullanme" autocomplete="off" required />
                                    </div>
                                    <div class="form-group">
                                        <label>Mobile Number :</label>
                                        <input class="form-control" type="text" name="mobileno" maxlength="10" autocomplete="off" required />
                                    </div>
                                    <div class="form-group">
                                        <label>Enter Email</label>
                                        <input class="form-control" type="email" name="email" id="emailid" onBlur="checkAvailability()"  autocomplete="off" required  />
                                        <span id="user-availability-status" style="font-size:12px;"></span> 
                                    </div>
                                    <div class="form-group">
                                        <label>Enter Password</label>
                                        <input class="form-control" type="password" name="password" autocomplete="off" required  />
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm Password </label>
                                        <input class="form-control"  type="password" name="confirmpassword" autocomplete="off" required  />
                                    </div>
                                    <button type="submit" name="signup" class="btn btn-danger" id="submit">Register Now</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php'); ?>
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>

