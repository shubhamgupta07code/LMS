<div class="navbar navbar-inverse set-radius-zero">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand">
                <img src="assets/img/library.svg" />
            </a>
        </div>

        <div class="right-div">
            <a href="logout.php" class="btn btn-danger pull-right">LOG ME OUT</a>
        </div>
    </div>
</div>
<!-- LOGO HEADER END-->
<section class="menu-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-collapse collapse">
                    <ul id="menu-top" class="nav navbar-nav navbar-right">
                        <li><a href="dashboard.php" class="menu-top-active">DASHBOARD</a></li>
                        <li>
                            <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Categories <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="add-category.php">Add Category</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-categories.php">Manage Categories</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Authors <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="add-author.php">Add Author</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-authors.php">Manage Authors</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Books <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="add-book.php">Add Book</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-books.php">Manage Books</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> Issue Books <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="issue-book.php">Issue New Book</a></li>
                                <li role="presentation"><a role="menuitem" tabindex="-1" href="manage-issued-books.php">Manage Issued Books</a></li>
                            </ul>
                        </li>
                        <li><a href="reg-students.php">Reg Students</a></li>
                        <li><a href="change-password.php">Change Password</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    /* General Styles */
    body {
        font-family: 'Open Sans', sans-serif;
        background: linear-gradient(to right, #8e44ad, #3498db);
        margin: 0;
        padding: 0;
    }

    /* Navbar Styles */
    .navbar {
        background-color: rgba(52, 73, 94, 0.8);
        border: none;
        border-radius: 0;
        margin-bottom: 0;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    }

    .navbar-brand img {
        max-height: 100px;
        padding-bottom: 15px;
    }

    .navbar-toggle {
        background-color: #fff;
        border: none;
    }

    .icon-bar {
        background-color: #8e44ad;
    }

    /* Menu Styles */
    .menu-section {
        background-color: rgba(52, 152, 219, 0.9);
        padding: 10px 0;
        box-shadow: 0px 4px 2px -2px gray;
        border-radius: 10px;
    }

    #menu-top {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    #menu-top li {
        display: inline-block;
    }

    #menu-top li a {
        color: #fff;
        font-size: 16px;
        font-weight: bold;
        padding: 10px 20px;
        text-decoration: none;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
        transition: background 0.3s, color 0.3s, transform 0.2s;
    }

    #menu-top li a:hover,
    #menu-top li a.menu-top-active {
        background: linear-gradient(45deg, #3498db, #9b59b6);
        color: #fff;
        transform: scale(1.05);
    }

    /* Dropdown Menu Styles */
    .dropdown-menu {
        background-color: rgba(142, 68, 173, 0.9);
        border: none;
        border-radius: 0 0 10px 10px;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.3);
    }

    .dropdown-menu li a {
        color: #ecf0f1;
        padding: 10px 20px;
        display: block;
        white-space: nowrap;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
        transition: background 0.3s, color 0.3s, transform 0.2s;
    }

    .dropdown-menu li a:hover {
        background: linear-gradient(45deg, #9b59b6, #3498db);
        color: #fff;
        transform: scale(1.05);
    }

    /* Logout Button */
    .right-div {
        padding-top: 15px;
    }

    .btn-danger {
        background: linear-gradient(45deg, #e74c3c, #c0392b);
        border: none;
        color: #fff;
        padding: 10px 20px;
        text-transform: uppercase;
        border-radius: 50px;
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.3);
        transition: background 0.3s, transform 0.2s ease-in-out;
    }

    .btn-danger:hover {
        background: linear-gradient(45deg, #c0392b, #e74c3c);
        transform: scale(1.05);
    }
</style>
