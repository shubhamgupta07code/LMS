<?php
session_start();
error_reporting(0);
include('includes/config.php');
if($_SESSION['login']!=''){
$_SESSION['login']='';
}
if(isset($_POST['login']))
{

$email=$_POST['emailid'];
$password=md5($_POST['password']);
$sql ="SELECT EmailId,Password,StudentId,Status FROM tblstudents WHERE EmailId=:email and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);

if($query->rowCount() > 0)
{
 foreach ($results as $result) {
 $_SESSION['stdid']=$result->StudentId;
if($result->Status==1)
{
$_SESSION['login']=$_POST['emailid'];
echo "<script type='text/javascript'> document.location ='dashboard.php'; </script>";
} else {
echo "<script>alert('Your Account Has been blocked .Please contact admin');</script>";

}
}

} 

else{
echo "<script>alert('Invalid Details');</script>";
}
}

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Shubham & Mukesh | Online LMS</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

    <!-- CUSTOM 3D STYLE -->
    <style>
        /* Body background and container styling */
        body {
            background: linear-gradient(to right, #8e44ad, #3498db);
            font-family: 'Open Sans', sans-serif;
        }
        .content-wrapper {
            margin-top: 50px;
        }

        /* Header styling */
        .header-line {
            color: white;
            font-weight: bold;
            text-align: center;
            text-shadow: 2px 2px 5px rgba(0,0,0,0.3);
        }

        /* Panel and form styling */
        .panel {
            background: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }
        .panel-heading {
            background: linear-gradient(45deg, #3498db, #9b59b6);
            color: white;
            font-size: 18px;
            font-weight: bold;
            border-radius: 10px 10px 0 0;
            text-align: center;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
            padding: 15px;
        }
        .panel-body {
            padding: 30px;
        }

        /* Updated Carousel Styling */
        .carousel-inner {
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }

        .carousel-caption {
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            padding: 10px 20px;
            bottom: 20px;
        }

        .carousel-caption h3 {
            font-size: 24px;
            font-weight: bold;
        }

        .carousel-caption p {
            font-size: 16px;
        }

        .carousel-indicators li {
            background-color: #3498db;
            border-radius: 50%;
        }

        .carousel-indicators .active {
            background-color: #9b59b6;
        }

        /* Adjustments for mobile view */
        @media (max-width: 768px) {
            .panel {
                margin-top: 20px;
            }
        }
        .carousel-indicators {
    bottom: -16px;
}
    </style>
</head>
<body>
    <!------MENU SECTION START-->
    <?php include('includes/header.php'); ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <!--Slider---->
            <div class="row">
                <div class="col-md-10 col-sm-8 col-xs-12 col-md-offset-1">
                    <div id="carousel-example" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="item active">
                                <img src="assets/img/1.jpg" alt="Library Image 1" />
                                <div class="carousel-caption">
                                    <h3>Welcome to Shubham and Mukesh Library</h3>
                                    <p>Explore a world of knowledge</p>
                                </div>
                            </div>
                            <div class="item">
                                <img src="assets/img/2.jpg" alt="Library Image 2" />
                                <div class="carousel-caption">
                                    <h3>Diverse Collection</h3>
                                    <p>Books for all ages and interests</p>
                                </div>
                            </div>
                            <div class="item">
                                <img src="assets/img/3.jpg" alt="Library Image 3" />
                                <div class="carousel-caption">
                                    <h3>Quiet and Comfortable</h3>
                                    <p>Your perfect study environment</p>
                                </div>
                            </div>
                        </div>
                        <!--INDICATORS-->
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example" data-slide-to="1"></li>
                            <li data-target="#carousel-example" data-slide-to="2"></li>
                        </ol>
                    </div>
                </div>
            </div>
            <hr />

            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">ABOUT OUR LIBRARY MANAGEMENT SYSTEM</h4>
                </div>
            </div>         
            <!--INFORMATION PANEL START-->           
            <div class="row">
                <div class="col-md-8 col-sm-8 col-xs-12 col-md-offset-2">
                    <div class="panel panel-info">
                    <div class="panel-heading" style="color: white;">
                            S&M LIBRARY MANAGEMENT SYSTEM
                        </div>
                        <div class="panel-body">
                            <p>
                                S&M (Shubham and Mukesh) have developed a cutting-edge Library Management System (LMS) designed to make library operations seamless and efficient. This system offers a wide range of functionalities, including catalog management, user registration, and book lending processes, all accessible through an intuitive online interface.
                            </p>
                            <p>
                                The LMS is built using the latest web technologies, ensuring it is both secure and scalable. It allows users to browse an extensive collection of books, manage their borrowing history, and reserve books online. Administrators benefit from streamlined workflows for book management and user tracking, making this system an essential tool for modern libraries.
                            </p>
                            <p>
                                The system is already in use and has proven to be a valuable resource for both library staff and patrons, enhancing the overall library experience. With continuous updates and improvements, Shubham and Mukesh are committed to maintaining a state-of-the-art system that meets the evolving needs of libraries and their users.
                            </p>
                        </div>
                    </div>
                </div>
            </div>  
            <!---INFORMATION PANEL END-->            
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php'); ?>
    <!-- FOOTER SECTION END-->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>

    <!-- JavaScript for smooth transitions -->
    <script>
        $('.carousel').carousel({
            interval: 5000,  // Slide interval (in milliseconds)
            pause: "hover"   // Pause on hover
        });
    </script>
</body>
</html>

