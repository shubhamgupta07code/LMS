<section class="footer-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
               &copy; <?php echo date('Y');?> S&M Library Management System
            </div>
        </div>
    </div>
</section>

<style>
    .footer-section {
        background-color: #f8f9fa; /* Optional: Set background color for the footer */
        padding: 20px 0; /* Optional: Add padding to the footer */
    }
    
    .footer-section .col-md-12 {
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
    }
</style>
